<?php  include('inc/header.php');  ?> 

<?php  require_once('inc/db.php');  ?>

    <div class="container">
        <div class="row">
            <div class="col-sm-12">
                <h1 class="text-center display-4 border p-3 my-5 "> Login System Using PHP </h1>
            </div>
        </div>
    </div>

<?php  include('inc/footer.php');  ?> 
